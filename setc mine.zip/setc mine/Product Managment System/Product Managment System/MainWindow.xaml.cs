﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using RBA_DAL;
using RBA_Entities;
using RBA_Exception;
using System.Data.SqlClient;
using System.Data;
using RBA_BAL;

namespace Product_Managment_System
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
     
        
        SqlConnection connection= new SqlConnection(connStr);
        SqlCommand command;
        DataTable dtStudent = new DataTable();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            command = new SqlCommand();
            command.CommandText = "NextProductId_172303_12";
            command.Connection = connection;
            command.CommandType = CommandType.StoredProcedure;
       
            try
            {
                connection.Open();
                object nxId = command.ExecuteScalar();
                txt_Pid.Text = nxId.ToString();



            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        private void btn_Insert_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Product product = new Product
                {
                    ProductName = txt_Pname.Text,
                    Description = txt_Desc.Text,
                    UnitPrice = decimal.Parse(txt_Price.Text)
                };

                Class1 pb = new Class1();
                int pid = pb.AddProductBAL(product);
                MessageBox.Show(string.Format("New Product Added.\nProduct Id: {0}", pid),
                    "Product Management System");
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void btn_Display_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Class1 st = new Class1();
                DataTable dt = st.DisplayProductBal();
                dt_Display.ItemsSource = dt.DefaultView;


            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "employee Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
